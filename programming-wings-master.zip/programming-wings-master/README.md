# face_recognition on image based attendance system

make confirm about all the packages are installed in your computer or not

if not install all

give the full path in your Terminal like this cd Desktop/programming wings

And then start Execution using python attendance.py

before that you should have python in your computer

my suggestion is to use visual studio code and it is better than pycharm,spyder and all other IDE

after opening the GUI enter the all details and click capture

after capturing click train 

after training click track and followed by quit

during training it will create .yml file and .csv file 



# FLOWER_CLASSIFICATION
 
 search for image classification using tensorflow by GOOGLE
 
 find it out and download notebook
 
 open the downloaded file using jupyter notebook
 
 run the all tabs and enjoy it.......
